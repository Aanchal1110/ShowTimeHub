package com.EventTicketBookingWebApp.EventTicketBookingWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventTicketBookingWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventTicketBookingWebAppApplication.class, args);
	}
}
