package com.EventTicketBookingWebApp.EventTicketBookingWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventTicketBookingWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
